package org.example;

import game.dungeon.Dungeon;

public interface LeerDungeonTXT {
    public Dungeon getDungeonfromTXT();
}
