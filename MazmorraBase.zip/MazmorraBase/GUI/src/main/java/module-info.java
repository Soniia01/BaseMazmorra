module GUI {
    requires javafx.graphics;
    requires jakarta.jakartaee.web.api;
    requires javafx.controls;
    requires javafx.fxml;
}