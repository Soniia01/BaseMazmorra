package org.example.controllers;

import jakarta.enterprise.inject.Instance;
import jakarta.inject.Inject;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import org.example.controllers.common.BaseScreenController;
import org.example.controllers.common.Screens;

import java.io.IOException;
import java.util.Optional;

public class PrincipalController {
    Instance<Object> instance;
    private Stage primaryStage;
    @FXML
    public BorderPane root;
    private final Alert alert;

    @Inject
    public PrincipalController(Instance<Object> instance) {
        alert= new Alert(Alert.AlertType.NONE);

    }
    public void initialize() {
        cargarPantalla(Screens.LOGIN);
    }
    private void cargarPantalla(Screens pantalla) {
        cambioPantalla(cargarPantalla(pantalla.getRuta()));
    }
    public void sacarAlertError(String mensaje) {
        alert.setAlertType(Alert.AlertType.ERROR);
        alert.setContentText(mensaje);
        alert.getDialogPane().setId("alert");
        alert.getDialogPane().lookupButton(ButtonType.OK).setId("btn-ok");
        alert.showAndWait();
    }
    public void sacarAlertInfo(String mensaje) {
        alert.setAlertType(Alert.AlertType.INFORMATION);
        alert.setContentText(mensaje);
        alert.isResizable();
        alert.getDialogPane().setId("alert");
        alert.getDialogPane().lookupButton(ButtonType.OK).setId("btn-ok");
        alert.showAndWait();
    }
    public boolean sacarAlertConf(String mensaje) {
        alert.setAlertType(Alert.AlertType.CONFIRMATION);
        alert.setContentText(mensaje);
        alert.isResizable();
        alert.getDialogPane().setId("alert");
        alert.getDialogPane().lookupButton(ButtonType.OK).setId("btn-ok");
        alert.getDialogPane().lookupButton(ButtonType.CANCEL).setId("btn-cancel");
        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }
    private Pane cargarPantalla(String ruta) {
        Pane panePantalla = null;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setControllerFactory(controller -> instance.select(controller).get());
            panePantalla = fxmlLoader.load(getClass().getResourceAsStream(ruta));
            BaseScreenController pantallaController = fxmlLoader.getController();
            pantallaController.setPrincipalController(this);
            pantallaController.principalCargado();


        } catch (IOException e) {
            e.printStackTrace();
        }
        return panePantalla;
    }
    private void cambioPantalla(Pane pantallaNueva) {
        root.setCenter(pantallaNueva);
    }
    public void exit(ActionEvent actionEvent) {
        primaryStage.fireEvent(new WindowEvent(primaryStage, WindowEvent.WINDOW_CLOSE_REQUEST));
    }
    public void setStage(Stage stage) {
        primaryStage = stage;
    }

    @FXML
    private void menuClick(ActionEvent actionEvent) {

        switch (((MenuItem)actionEvent.getSource()).getId())
        {
            case "menuCustList":
                cargarPantalla(Screens.CUSTOMERLIST);
                break;
            case "menuCustAdd":
                cargarPantalla(Screens.CUSTOMERADD);
                break;
            case "menuCustUpdate":
                cargarPantalla(Screens.CUSTOMERUPDATE);
                break;
            case "menuCustDelete":
                cargarPantalla(Screens.CUSTOMERDELETE);
                break;
            case "menuOrdList":
                cargarPantalla(Screens.ORDERLIST);
                break;
            case "menuOrdAdd":
                cargarPantalla(Screens.ORDERADD);
                break;
            case "menuOrdUpdate":
                cargarPantalla(Screens.ORDERUPDATE);
                break;
            case "menuOrdDelete":
                cargarPantalla(Screens.ORDERDELETE);
                break;
        }

    }
}