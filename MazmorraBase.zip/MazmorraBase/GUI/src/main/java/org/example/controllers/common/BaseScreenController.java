package org.example.controllers.common;

import org.example.controllers.PrincipalController;

public abstract class BaseScreenController {

    private PrincipalController principalController;
    public void setPrincipalController(PrincipalController principalController) {
        this.principalController = principalController;
    }
    abstract public void principalCargado();

    public PrincipalController getPrincipalController() {
        return principalController;
    }
}
