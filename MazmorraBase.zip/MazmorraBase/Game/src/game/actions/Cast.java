package game.actions;

public interface Cast {

    public int cast(String param, int value);
}
