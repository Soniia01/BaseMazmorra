package game.character.exceptions;

public class CharacterKilledException extends Throwable {
}
