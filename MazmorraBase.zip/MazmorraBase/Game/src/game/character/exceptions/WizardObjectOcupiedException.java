package game.character.exceptions;

public class WizardObjectOcupiedException extends Throwable {
}
