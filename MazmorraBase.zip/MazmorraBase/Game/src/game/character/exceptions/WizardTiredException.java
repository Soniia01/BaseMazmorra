package game.character.exceptions;

public class WizardTiredException extends Throwable {
}
