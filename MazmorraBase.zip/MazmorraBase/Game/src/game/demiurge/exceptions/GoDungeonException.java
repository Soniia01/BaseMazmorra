package game.demiurge.exceptions;

public class GoDungeonException extends Throwable {
}
