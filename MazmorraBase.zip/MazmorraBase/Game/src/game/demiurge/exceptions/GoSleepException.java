package game.demiurge.exceptions;

public class GoSleepException extends Throwable {
}
