package game.object;

public class ItemCreationErrorException extends Throwable {
}
