package game.spell;

public class SpellUnknowableException extends Throwable {
}
