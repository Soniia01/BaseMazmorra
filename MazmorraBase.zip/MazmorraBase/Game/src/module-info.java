module Game {
    exports game.dungeon;
}