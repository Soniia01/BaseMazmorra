package org.example;

import game.dungeon.Dungeon;

public interface GuardarDungeon {
    //Save dungeon on XML & TXT Binario
}