package org.example.xml;

public class DoorXML {
}
