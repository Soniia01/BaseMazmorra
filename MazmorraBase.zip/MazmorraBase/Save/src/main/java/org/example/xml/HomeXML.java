package org.example.xml;

public class HomeXML {
}
