package org.example.xml;

public class RoomXML {
}
