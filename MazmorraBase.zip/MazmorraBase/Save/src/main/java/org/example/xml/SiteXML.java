package org.example.xml;

public class SiteXML {
}
